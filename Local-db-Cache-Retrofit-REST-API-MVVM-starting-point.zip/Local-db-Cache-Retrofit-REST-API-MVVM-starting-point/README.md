# Local-db-Cache-Retrofit-REST-API-MVVM
App that interacts with a REST API using Retrofit. There is a local db cache and architecture is MVVM.
<br><br>
This is a work in progress.
